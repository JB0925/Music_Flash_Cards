# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['music_flash_cards']

package_data = \
{'': ['*'],
 'music_flash_cards': ['chromatic_note_cards/*',
                       'correct_and_incorrect_cards/*']}

install_requires = \
['Pillow>=8.0.1,<9.0.0', 'PyAudio>=0.2.11,<0.3.0']

setup_kwargs = {
    'name': 'music-flash-cards',
    'version': '0.1.0',
    'description': '',
    'long_description': '# Music Flash Cards\n<!-- Brief description of what you can do with this program -->\n\n## Hardware Requirements\n\n- Working Microphone\n\n## Installation\n\n### Windows Installation Instructions\n\n### MacOS Installation Instructions\n\nBefore installing `music_flash_cards` you will need to install\n[PortAudio][1], which is easily accomplished with the [brew][2]\npackage manager:\n\n```console\n$ brew install portaudio\n$ python3 -m pip install music_flash_cards\n```\n\n### Linux Installation Instructions\n\n\n## Usage\n<!-- Short explanation of how to run the tool -->\n\n## Development\n<!-- Describe the development process and tools -->\n\nThe general development process is:\n\n- Edit \n- Test\n- Bump version\n- Publish \n\n### Packaging\n\nPackaging and prerequisites are managed using the [Poetry][3] tool.\n\n#### Versioning\n\n```console\n$ cd /path/to/music_flash_cards\n$ poetry version\n...\n```\n\n#### Building\n```console\n$ python3 -m pip install -U pip poetry\n$ cd /path/to/music_flash_cards\n$ poetry build\n...\n$ ls dist/\n...\n```\n\n#### Release\n\nAssuming the user has their [PyPI][4] credentials, `poetry` can be\nused to publish the package. Credentials can be supplied at the\ncommand-line or managed via poetry (creds are not stored in the\nrepository).\n\n```console\n$ poetry publish\n...\n```\n\n\n#### Testing\n\n<!-- stuff about testing with ptyest will go here -->\n\n\n## ToDo List\n<!-- list of future features/enhancments -->\n\n\n<!-- End Links -->\n\n[1]: http://people.csail.mit.edu/hubert/pyaudio/\n[2]: https://brew.sh\n[3]: https://python-poetry.org/docs/\n',
    'author': 'Your Name',
    'author_email': 'you@example.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.8,<4.0',
}


setup(**setup_kwargs)
